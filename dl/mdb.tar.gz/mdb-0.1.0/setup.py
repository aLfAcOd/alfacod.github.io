from setuptools import setup, find_packages
setup(
name='mdb',
version='0.1.0',
author='Mojtabadev',
author_email='m6588817@gmail.com',
description='you can save and use your variables forever',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)