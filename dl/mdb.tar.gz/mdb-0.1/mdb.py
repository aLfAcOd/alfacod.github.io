import os
import random as r




def _def(name:str):
    try:
        file = open(f"{name}.exe","x")
        file.close()
    except:
        print("this variable already exits. use _write()")


def _write(name:str,type:str,value:any):
    fpath = f"{name}.exe"
    n = "0"
    ls = os.listdir()
    ###################################
    for i in ls:
        if i.replace(".exe","") != name:
            pass
        elif i.replace(".exe","") == name:
            n = "1"
    if n == "1":
        if type =="str":
            f = open(fpath,"w")
            f.write(f"{str(value)}^")
        elif type =="int":
            f = open(fpath,"w")
            f.write(f"{value}~")
    f.close()
def _read(name):
    fpath = f"{name}.exe"
    ###################################
    try:
        f = open(fpath,"r")
        f = f.read()
        if "^" in f:
            f = f.replace("^","")
            return str(f)
        if "~" in f:
            f = f.replace("~","")
            return int(f)
    
    except:
        print("file don't exits!")


def _delete(name):
    try:
        os.remove(f"{name}.exe")
    except:
        print("file don't exits!")


def _export(name,code:int):
    try:
        src = f"{name}.exe"
        dst = f"{name}{code}"
        with open(src, 'rb') as fsrc:
            with open(dst, 'wb') as fdst:
                fdst.write(fsrc.read())
    except FileNotFoundError:
        print("Source file doesn't exist!")


#wirte _import() finction too
def _import(name, code:int):
    try:
        src = f"{name}{code}"
        dst = f"{name}.exe"
        with open(src, 'rb') as fsrc:
            with open(dst, 'wb') as fdst:
                fdst.write(fsrc.read())
    except FileNotFoundError:
        print("Source file doesn't exist!")