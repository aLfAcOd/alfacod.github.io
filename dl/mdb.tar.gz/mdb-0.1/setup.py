from setuptools import setup, find_packages

setup(
    name='mdb',
    version='0.1',
    packages=find_packages(),
    py_modules=['mdb'],
    install_requires=[],
    author='Mojtabadev',
    author_email='alfacode2023@gmail.com',
    description='A description of your library',
    url='https://github.com/yourusername/mdb',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)